<?php session_start();
include_once("html/htmlBasico/head.php");
if (!isset($_SESSION['usuario'])) {
	include_once("html/htmlBasico/menu.php");
} else if($_SESSION['usuario'] == "admin") {
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'> 	
  		<li class='blue light-blue darken-2'><a href='processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='html/conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='html/conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='html/conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='index.php' class='brand-logo'><img src='img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='html/sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='html/importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='html/classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='html/editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
  				<li><a href='processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='html/conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='html/conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='html/conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='html/sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='html/importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='html/classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='html/editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
			</ul>
		</div>
	</nav>";
	}else{
		$id = $_SESSION['id'];		
		echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='html/conta.php?id=$id' class='white-text'>Conta</a></li> 	
  		<li class='blue light-blue darken-2'><a href='processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='index.php' class='brand-logo'><img src='img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='html/sports.php?id=$id' class='white-text fontMenu'>Sports</a></li>
				<li><a href='html/importados.php?id=$id' class='white-text fontMenu'>Importados</a></li>
				<li><a href='html/classicos.php?id=$id' class='white-text fontMenu'>Clássicos</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><img width='60px' style='margin-top:10px;' src='processas/exibirImg/exibir.php?id=$id' class='circle' /></li>
			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='html/conta.php?id=$id' class='blue-text'>Conta</a></li> 	
  				<li><a href='processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='html/sports.php?id=$id' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='html/importados.php?id=$id' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='html/classicos.php?id=$id' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
			</ul>
		</div>
	</nav>";
	}
include_once("html/home.php");
include_once("html/htmlBasico/rodape.php");
include_once("html/htmlBasico/links.php");
?>