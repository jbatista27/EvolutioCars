$(document).ready(function(){
  $('.parallax').parallax();
  $('.materialboxed').materialbox();
  $(".button-collapse").sideNav();
  $('').scrollToFixed({
  	bottom: 0
  });
  $('.slider').slider();
  $('.modal').modal();
  $('.collapsible').collapsible();
  $('.carousel').carousel();
  $('.carousel.carousel-slider').carousel({fullWidth: true});
  $('.dropdown-button').dropdown('open');
  $('.dropdown-button').dropdown('close');
  $('select').material_select();
});
