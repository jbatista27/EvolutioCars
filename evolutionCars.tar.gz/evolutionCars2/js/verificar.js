var formulario = document.forms.FormCadastro;
var button = document.getElementById('enviar');
    button.onclick = function validar() {
          var senha = formulario.senha.value;
          var csenha = formulario.ConfirSenha.value;
        if (senha != csenha){
          swal(
            'Erro ao Enviar',
            'Senhas Diferentes!',
            'error'
          );
          return false;
        }else if(senha.length < 6){
          swal(
            'Erro ao Enviar',
            'Senha deve conter no minimo 6 caracteres!',
            'error'
          );
          return false;
        }else{}
    }