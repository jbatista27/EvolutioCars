<?php
include_once("Conexao.php");
    	$conexao = new Conexao();
    	$home = $conexao->getCon()->prepare("SELECT home.id,home.nomeCarro,home.descricao,curiosidade.curiosidade,home.imagem
     	FROM home INNER JOIN curiosidade ON home.curiosidade=curiosidade.id;");
     	$home->execute();
        $mobile = $conexao->getCon()->prepare("SELECT home.id,home.nomeCarro,home.descricao,curiosidade.curiosidade,home.imagem
     	FROM home INNER JOIN curiosidade ON home.curiosidade=curiosidade.id;");
     	$mobile->execute();
echo"<!-- CONTEUDO  MOBILE -->
	<div class='visibleDesktop'>
		<center><h3 class='fontMenu'>NOVIDADES!</h3></center>
	</div>
	<br class='visibleDesktop' />
	<!-- NOCITA1 MOBILE -->
	<div class='row visibleDesktop'>
		<div class='col s12'>
			<h5>1. Lamborghini Egoista</h5>
		</div>
		<div class='col  s12'>
			<img class='responsive-img materialboxed z-depth-1' src='https://pictures.topspeed.com/IMG/crop/201305/2013-lamborghini-egoista-9_800x0w.jpg'>
		</div>
		<div class='col s12'><br />
			<div class='card-paniel blue darken-2 z-depth-1'>
				<p class='white-text textoJustificado'>
					Este é definitivamente um Lamborghini que o motorista pode chamar de seu. E o nome da máquina não poderia ser mais adequado: Egoista. O protótipo de apenas um lugar.O Lamborghini Egoista vem equipado com um motor V10 de 5.2 litros com potência de 600 cv, com inspiração no mundo da aviação, em particular no helicóptero de combate Apache, no qual o cockpit pode ser ejetado em uma emergência. Aliás, a cabine é completamente feita em alumínio e fibra de carbono e, de acordo com De Silva, o carro foi projetado com a ideia de que seu habitáculo poderia ter sido retirado de um avião a jato e integrado ao veículo, proporcionando ao motorista uma nova experiência de condução.
				</p>
			</div>
		</div>
	</div>
	<br class='visibleDesktop' />
	<hr class='visibleDesktop' />
	<!-- NOTICIA2 MOBILE -->
	<div class='row visibleDesktop'>
		<div class='col s12'>
			<h5>2.Novo Mustang Shelby GT350</h5>
		</div>
		<div class='col  s12'>
			<img class='responsive-img materialboxed z-depth-1' src='http://www.canal2.com.br/wp-content/uploads/2015/03/2016_ford_mustang_shelby_gt350r_1_1280x960.jpg'>
		</div>
		<div class='col s12'><br />
			<div class='card-paniel blue darken-2 z-depth-1'>
				<p class='white-text textoJustificado'>
					A Ford anunciou que o Mustang Shelby GT350 terá o motor naturalmente aspirado de série mais potente da história da marca, o V8 5.2, com 533 cv e torque de 59,3 kgfm. Esse V8 5.2 naturalmente aspirado com virabrequim de perfil plano e alta rotação atende todas as metas que estabelecemos – alta potência, ampla curva de torque, resposta agressiva do acelerador e baixo peso. O novo V8 5.2 é não só o motor naturalmente aspirado mais potente da Ford em todos os tempos, mas também o mais eficiente em termos de potência específica. Sem turbo ou sobrealimentação, ele gera 103 cv por litro. É também o motor de giro mais alto da história Ford ­- com zona vermelha em 8.250 rpm. 
				</p>
			</div>
		</div>
	</div>
	<br class='visibleDesktop' />
	<hr class='visibleDesktop' />
	<!--  NOTICIA3 MOBILE -->
	<div class='row visibleDesktop'>
		<div class='col s12'>
			<h5>3. CHEVROLET CAMARO ZL1</h5>
		</div>
		<div class='col  s12'>
			<img class='responsive-img materialboxed z-depth-1' src='http://st.motortrend.com/uploads/sites/5/2016/11/2017-Chevrolet-Camaro-RS-2LT-V-6-Performance-Parts-front-three-quarter-02.jpg'>
		</div>
		<div class='col s12'><br />
			<div class='card-paniel blue darken-2 z-depth-1'>
				<p class='white-text textoJustificado'>
					o Camaro topo de linha agora vem com o motor 6.8 V8 do Corvette Z06, que foi reconfigurado para entregar 648 cavalos de potência e 88,5 kgfm de torque. Além disso, o esportivo perdeu 91 quilos, o que deve garantir uma aceleração de 0 a 100 km/h ainda mais rápida do que os 4 segundos da versão anterior.
				</p>
			</div>
		</div>
	</div>
	<hr class='visibleDesktop' />
	<br class='visibleDesktop' />
	<!-- NOTICIA4 MOBILE -->
	<div class='row visibleDesktop'>
		<div class='col  s12'>
			<h5>4. Novo Volvo S90</h5>
			<img class='responsive-img materialboxed z-depth-1' src='http://st.automobilemag.com/uploads/sites/10/2016/05/2017-Volvo-S90-in-white3.jpg'>
		</div>
		<div class='col s12'><br />
			<div class='card-paniel blue darken-2 z-depth-1'>
				<p class='white-text textoJustificado'>
					Para este carro, não é tão simples se manter abaixo dos 120 km/h ao volante de um sedã capaz de despejar 320 cv de potência e 40,7 kgfm de torque em suas quatro rodas. O câmbio automático de oito marchas trabalha de forma suave e precisa, sempre tentando equilibrar o consumo de combustível. Se você desejar mais esportividade, basta selecionar o modo Dynamic no elegante seletor central do console, que ainda conta com os modos Comfort e Eco. A direção fica mais pesada, o conta-giros sobe e as respostas do acelerador se tornam mais sensíveis. Mas o carro ainda mantém a educação sueca e a voz baixa. Não espere um ronco estridente do motor e nem um comportamente dinâmico mais agressivo. Afinal, o S90 é de fato um sedã executivo ao estilo sueco, que prima pela solidez e equilíbrio em curvas, mas não estimula excessos.
				</p>
			</div>
		</div>
	</div>
        <hr class='visibleDesktop' />
	<br class='visibleDesktop' />";
        foreach ($mobile as $mostra) {
	echo"<div class='row visibleDesktop'>
		<div class='col s12'>
			<h5>{$mostra['nomeCarro']}</h5>
		</div>
		<div class='col  s12'>
			<img src='processas/exibirImg/exibirImgConteudo.php?id={$mostra['id']}&dados=home' class='responsive-img materialboxed z-depth-1'/>
		</div>
		<div class='col s12'><br />
			<div class='card-paniel blue darken-2 z-depth-1'>
				<p class='white-text textoJustificado'>{$mostra['descricao']}</p>
			</div>
		</div>
	</div>
	<br class='visibleDesktop' />
	<hr class='visibleDesktop' />";
	}
	echo"<br />
	<!-- INTRODUÇÃO COMPUTADOR -->
	<div class='container divBorda visibleMobile'>
		<div class='section white'>
			<div class='row'>
				<div class='col l6 m6'>
					<h4 class='header textoJustificado'>Qual é o Intuito do Site?</h4>
					<p class='textoJustificado'>O intuito deste site é mostrar para você usuário, uns tipos de carros na qual pode você ter visto mas também conhecer carros novos e saber sobre suas informações como por exemplo: Motor, potência, se é eletrico ou não, se é econômico ou não, etc. Aproveite o site!!!</p>
				</div>
				<div class='col l6 m6'>
					<ul class='collapsible popout' data-collapsible='accordion'>
						<li>
							<div class='collapsible-header fontMenu'><i class='material-icons'>filter_drama</i>Desenvolvedor</div>
							<div class='collapsible-body'>João Batista<span></span></div>
						</li>
						<li>
							<div class='collapsible-header fontMenu'><i class='material-icons'>place</i>Escola</div>
							<div class='collapsible-body'><span>E.E.E.P. Paulo Petrola</span></div>
						</li>
						<li>
							<div class='collapsible-header fontMenu'><i class='material-icons'>whatshot</i>Professor</div>
							<div class='collapsible-body'><span>Clemilton Lima De Souza</span></div>
						</li>
					</ul>
				</div>    
			</div>
		</div>
	</div>
	<br />
	<!-- PARALAX 1 -->
	<div class='parallax-container visibleMobile'>
		<div class='parallax'><img src='http://s2.glbimg.com/wzMTFxLk8dQFmk0mcSOUUYa5Pag=/620x413/e.glbimg.com/og/ed/f/original/2015/01/07/audi-prologue-l140075.jpg'></div>
	</div>
	<br />
	<!-- NOTICIA1 COMPUTADOR -->";
	echo"<div class='container divBorda visibleMobile'> <br class='visibleMobile' />";
		foreach ($home as $key) {
			echo "
			<div class='row visibleMobile '>
			<div class='col l7 m7'>
				<h4>{$key['nomeCarro']}</h4>
				<div>
					<p class='textoJustificado'>{$key['descricao']}</p>
				</div>
			</div>
			<div class='col l5 m5'>
				<div class='card'>
					<div class='card-image'>
						<img src='processas/exibirImg/exibirImgConteudo.php?id={$key['id']}&dados=home' />
						<span class='card-title sublinhado white-text'>Você sabia?</span>
					</div>
					<div class='card-content grey lighten-3'>
						<p>{$key['curiosidade']}</p>
					</div>
				</div>
			</div> 
		</div>
                <hr />
		<br class='visibleMobile' />";
		}
echo"</div>	
<br />";
	
?>	