<?php session_start();
include_once("htmlBasico/headPags.php");
if (!isset($_SESSION['usuario'])) {
	include_once("htmlBasico/menuPags.php");
}else if($_SESSION['usuario'] == "admin") {
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";
	}else{
		$id = $_GET['id'];
		echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='conta.php?id=$id' class='white-text'>Conta</a></li> 	
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php?id=$id' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php?id=$id' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php?id=$id' class='white-text fontMenu'>Clássicos</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><img width='60px' style='margin-top:10px;' src='../processas/exibirImg/exibir.php?id=$id' class='circle' /></li>
			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='conta.php?id=$id' class='blue-text'>Conta</a></li> 	
  				<li><a href='processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../img/logo.png' class='responsive-img'width=150px; heigth=30px;></center></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php?id=$id' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='htimportados.php?id=$id' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php?id=$id' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
			</ul>
		</div>
	</nav>";
	}
?>
<br class="visibleDesktop" />
	<!-- CONTEUDO MOBILE -->
	<!-- NOTICIA1 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://www.flatout.com.br/wp-content/uploads/2017/03/lambergine-furac%C3%A3o-performante-1.jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Lamborghini Huracán<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4 ">Imformações <i class="material-icons right">close</i></span>
					<p class="textoJustificado">O Huracán utiliza o mesmo bloco do motor do anterior Gallardo, um 5,2 litros V10. As alterações introduzidas permitiram aumentar a potência dos 520 cv do Gallardo LP-520-4 para 610 cv. O Huracan acelera dos 0 a 100 km/h em apenas 3,2 segundos e alcança a marca de 200 km/h em 9,5 segundos. O Huracán utiliza um novo tipo de chassis. A nova tecnologia do chassis foi desenvolvida em conjunto com a Audi e utiliza a chamada "fibra de carbono forjado". A nova estrutura de carbono e alumínio na carroceria permite que o veículo seja 10% mais leve e chegando a ser 50% mais rígida do que a do Gallardo.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA2 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgQGf5kjVvgEsM6c7_9kRXY2Pq1n39JN1w6Q5u79Uz7qDj7P5qpA">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Mercedes C300 <a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4 ">Imformações <i class="material-icons right">close</i></span>
					<p class="textoJustificado">Com um motor de 2.0 litros que gera 245 cv de potência e aceleração de 0 a 100 km/h em 6,4 segundos, o C 300 Cabriolet passa a oferecer mais uma opção de carroceria para umas das famílias mais bem-sucedidas da marca, comprovando sua versatilidade para atender diferentes perfis. Sua transmissão 9G-TRONIC de nove velocidades confere ao modelo uma agilidade acima do normal para um conversível desse porte.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA3 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://assets.bugatti.com/fileadmin/user_upload/Web/Pages/Models/Super_Sport/BUG_super_sport_05.jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Bugatti veyron<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4 ">Imformações <i class="material-icons right">close</i></span>
					<p class="textoJustificado">De acordo com o Grupo Volkswagen e certificado pela TÜV Süddeutschland, a versão final do Veyron produz 1.001 cavalos de potência e gera 1.250 N·m (127,4 kgf·m) de torque.2 28 De acordo com os funcionários da Bugatti, essa medida foi um tanto conservadora, sendo que a real potência verificada é de 1.020 cavalos a 6.000 rpm. Há uma variação de potência de motor a motor, o que explica essa medida conservadora. A velocidade máxima do carro sem o uso da chave especial é de 343 km/h. Quando o carro atinge 220 kmh, a suspensão hidráulica abaixa o carro até que ele tem uma distância ao solo de cerca de 9 cm. Ao mesmo tempo, a aerofólio hidráulico se abaixa. Neste modo, a asa fornece 3.425 newtons de downforce, grudando o carro na estrada.3</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA4 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkFlo0YGoqXCYVUOy2R6sLmeX3cEtaBjTLgPeBSEeMYQ38Tdrg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Jaguar F-Pace SUV<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4 ">Imformações <i class="material-icons right">close</i></span>
					<p class="textoJustificado">Os modelos do F-Pace a serem vendidos no Brasil são idênticos aos que circulam lá fora, com três opções de motorização, sendo a 2.0 a diesel, com 180 cavalos, inédita, toda construída na fábrica da Jaguar. Motor Ingenium Diesel, turbo, de 2.0 litros e 180 cv de potência. Esse diesel ainda será aplicado em carros da prima Land Rover, também comprada pela indiana Tata das mãos da Ford. Coube ao F-Pace estrear a motorização antes mesmo do Discovery Sport ou Evoque. Seu maior atrativo está no torque vigoroso, 43,8 kgfm entre 1.750 e 2.500 rotações, garantindo destreza em retomadas de velocidade e na transposição de terrenos irregulares.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA5 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="http://www.elitemagazine.com.br/livecomm/wp-content/uploads/2017/08/zbmw-097.jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">BMW i8<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4 ">Imformações <i class="material-icons right">close</i></span>
					<p class="textoJustificado">Na parte da frente do carro um motor elétrico gera 362 cv de potência, que permite ao BMW i8 ir de 0 a 100 km/h em apenas quatro segundos e também atingir velocidade máxima de 120 km/h no modo totalmente elétrico. Ao considerar o motor por combustão, o veículo pode atingir os 250 km/h. O intuito é que o motor elétrico seja usado na cidade, e o motor a combustão nas estradas. A ainda três modos de condução, vamos ver: Comfort,  usa o motor elétrico e é ideal para uso urbano em que a velocidade não precisa ser maior que 60 km/h. Eco Pro, que utiliza o motor elétrico até que a bateria fique baixa, e automaticamente use o motor a combustão em seguida. Sport é o programa dinâmico que usa o sistema híbrido e foca em otimizar a performance esportiva do veículo.</p>
				</div>
			</div>
		</div>
	</div>
        <?php 
	include_once("Conexao.php");
       	$conexao = new Conexao();
       	$mobile = $conexao->getCon()->query("SELECT * FROM importados;");
       	$infor ="sports";
		foreach ($mobile as $key) { 
		echo "<div class='row visibleDesktop'>
		<div class='col s12'>
			<div class='card'>
				<div class='card-image waves-effect waves-block waves-light'>
					<img class='activator' src='../processas/exibirImg/exibirImgConteudo.php?id={$key['id']}&dados=$infor'width=100%'>
				</div>
				<div class='card-content'>
					<span class='card-title activator grey-text text-darken-4'>{$key['nomeCarro']}<a class='btn-floating right circle red'><i class='material-icons right'>add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class='card-reveal'>
					<span class='card-title grey-text text-darken-4'>Imformações<i class='material-icons right'>close</i></span>
					<p class='textoJustificado'>{$key['descricao']}</p>
				</div>
			</div>
		</div>
	</div>";}
	?>
        <br  class="visibleMobile" />
	<!-- CONTEUDO DESKTOP -->
	<div class="container divBorda visibleMobile">
		<?php
		include_once("Conexao.php");
       	$conexao = new Conexao();
       	$sql = $conexao->getCon()->query("SELECT * FROM importados;");
       	$infor = "importados"; 
		foreach ($sql as $key) {
			echo "<hr /><!-- NOTICIA DESKTOP -->
				<div class='row visibleMobile'>
					<div class='col l12 m12'>
						<h4>{$key['nomeCarro']}</h4>
					</div>
					<div class='col l5 m5'>
						<img src='../processas/exibirImg/exibirImgConteudo.php?id={$key['id']}&dados=$infor'width=100% />
					</div>
					<div class='col l7 m7'>
						<div>
							<p class='textoJustificado'>{$key['descricao']}</p>
						</div>
					</div>
				</div>";	
		}?>
	</div>
	<br />
<?php
include_once("htmlBasico/rodapePags.php");
include_once("htmlBasico/linksPags.php");
?>			