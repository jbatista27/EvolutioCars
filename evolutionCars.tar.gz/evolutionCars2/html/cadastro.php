<?php 
include_once("htmlBasico/headPags.php");
include_once("htmlBasico/menuPags.php");
?>
<!-- CADASTRO -->
<div class="container">
 <div class="row">
  <fieldset><legend class="fontMenu">Ficha de Cadastro</legend>
   <form class="col s12 l12 m12" action="../processas/processa.php" method="post" name="FormCadastro">
    <div class="row">
     <div class="input-field col s12 l12 m12">
       <input id="last_name" type="text" name="usuario" id="usuario" class="validate" required/>
       <label for="last_name">Usuario</label>
     </div>
   </div>
   <div class="row">
    <div class="input-field col s12">
     <input id="email" type="email" name="email" id="email" class="validate" required>
     <label for="email" data-error="Email inválido" data-success="Email válido">Email</label>
   </div>
 </div>
 <div class="row">
  <div class="input-field col s12 l6 m6">
   <input id="password" type="password" name="senha" class="validate" required>
   <label for="password">Senha</label>
 </div>
 <div class="input-field col s12 l6 m6">
   <input type="password" id="password" name="ConfirSenha" class="validate" required>
   <label for="password">Confirmar Senha</label>
 </div>
</div>
<center>
  <button class="btn waves-effect light-blue darken-2" type="submit" name="action" id="enviar">Cadastrar
  </button>
</center>    
</form>
</fieldset>
</div>    		
</div>
<?php
include_once("htmlBasico/rodapePags.php");
include_once("htmlBasico/linksPags.php");
?>
