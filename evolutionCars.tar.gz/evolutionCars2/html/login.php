<?php 
include_once("htmlBasico/headPags.php");
include_once("htmlBasico/menuPags.php");
?>
<!-- Login -->
<div class="container"><br /><br />
	<div class="row">
		<fieldset>
		<legend class="fontMenu">Login</legend>
		   <form class="col s12 l12 m12" method="post" enctype="multipart/form-data" action="../processas/processaLogin.php">
			    <div class="row">
			      <div class="input-field col s12 l12 m12">
			    		<input id="last_name" type="text" name="usuario" class="validate">
			    		<label for="last_name">Usuario</label>
			    	</div>
				</div>	
				<div class="row">
			 		<div class="input-field col s12 l12 m12">
						<input id="password" type="password" name="senha" class="validate">
						<label for="password">Senha</label>
					</div>
				</div>
				<center>
					<button class="btn waves-effect light-blue darken-2" type="submit" name="action" >Entrar</button>
				</center>    
			</form>
		</fieldset>
	</div>   		
</div><br /><br />
<?php
include_once("htmlBasico/rodapePags.php");
include_once("htmlBasico/linksPags.php");
?>