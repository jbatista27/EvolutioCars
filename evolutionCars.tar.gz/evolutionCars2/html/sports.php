<?php session_start();
include_once("htmlBasico/headPags.php");
if (!isset($_SESSION['usuario'])) {
	include_once("htmlBasico/menuPags.php");
} else if($_SESSION['usuario'] == "admin") {
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";

	}else{
		$id = $_GET['id'];
		echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='conta.php?id=$id' class='white-text'>Conta</a></li> 	
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php?id=$id' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php?id=$id' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php?id=$id' class='white-text fontMenu'>Clássicos</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span>
					<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><img width='60px' style='margin-top:10px;' src='../processas/exibirImg/exibir.php?id=$id' class='circle' /></li>
			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='conta.php?id=$id' class='blue-text'>Conta</a></li> 	
  				<li><a href='../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php?id=$id' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='importados.php?id=$id' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php?id=$id' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
			</ul>
		</div>
	</nav>";
	}
?>
<!-- CONTEUDO MOBILE -->
	<!-- NOTICIA1 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">        
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://s2.glbimg.com/UhbU8h6KWcnJHoI4q-nk4bm8rdQ=/0x0:1900x1267/1000x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2017/M/y/NUvJkBSUaDVMecgAKRyg/audi-a5-tsfi-32a7736-credito-marcelo-brandt-g1.jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Audi A5 2.0 Sportback<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4 ">Imformações <i class="material-icons right">close</i></span>
					<p class="textoJustificado">O novo A5 impressionou pelo conforto e pelo desempenho da versão com 252 cv. De acordo com a fabricante, o A5 2.0 TFSI Sportback é capaz de acelerar de 0 a 100 km/h em 6 segundos e atingir 250 km/h de velocidade máxima.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA2 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://3.bp.blogspot.com/-Vac8x5yVwpY/WC7wcWkQ-NI/AAAAAAAA2GQ/rGckbzIF1xUta3uhE7aPLl_rDlz2U30YwCLcB/s640/Novo-Chevrolet-Tracker-2017%2B%25282%2529.jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Chevrolet SUV Tracker<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4">Imformações<i class="material-icons right">close</i></span>
					<p class="textoJustificado">O motor, o mesmo do Cruze, oferece 153 cavalos de potência e 24,5 kgfm de torque, estando associado com um câmbio automático de 6 marchas. O consumo do Tracker 1.4 Turbo Automático, segundo o INMETRO, é de 7,3 km/l de etanol em cidade, e 8,2 km/l em estrada. Com gasolina, o modelo faz 10,6 km/l em cidade, chegando a 11,7 km/l em estrada.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA3 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="http://i1.r7.com/data/files/2C95/948F/3C96/7E09/013C/97C2/84A2/42C3/Dart%20(9).jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Novo Dodge Dart<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4">Imformações<i class="material-icons right">close</i></span>
					<p class="textoJustificado">Motor: A gasolina, dianteiro, 1.999 cm³, quatro cilindros e quatro válvulas por cilindro. Injeção eletrônica multiponto seqüencial e acelerador eletrônico. Transmissão: Câmbio automático de seis velocidades à frente e uma a ré. Tração dianteira. Oferece controle eletrônico de tração. Potência máxima: 160 cv a 6.400 rpm. Aceleração 0-100 km/h: 8,5 s. Velocidade máxima: 210 km/h. Torque máximo: 20 kgfm a 4.800 rpm. Por dentro, é visível o investimento em tecnologia embarcada. Há uma grande tela sensível ao toque de 8,4 polegadas no centro do painel, que reúne diversas informações do carro, como o navegador e o sistema de som com bluetooth, além dos comandos no volante. Nas versões mais caras – são cinco no total: SE, SXT, Limited, Rallye e R/T –, ainda há outra tela configurável de 7 polegadas, entre os mostradores, que pode exibir apenas um velocímetro tradicional ou diversas outras combinações de instrumentos</p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA4 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://i.ytimg.com/vi/51_uLO2r2CI/maxresdefault.jpg">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Chery Tiggo 2<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4">Imformações<i class="material-icons right">close</i></span>
					<p class="textoJustificado">Motorização: 2.0, Alimentação Injeção multi ponto Combustível: Gasolina, Potência (cv):	135.0, Cilindrada(cm3):	1.971, Torque(Kgf.m): 18,6, Velocidade Máxima(Km/h): 170, Tempo 0-100(Km/h): N/D, Consumo cidade(Km/L): 7.9, Consumo estrada(Km/L):	9.8. Câmbio	Manual de 5 marchas. Tração Dianteira. Direção Hidráulica. Freios Quatro freios à disco com dois discos ventilados. </p>
				</div>
			</div>
		</div>
	</div>
	<!-- NOTICIA5 MOBILE -->
	<div class="row visibleDesktop">
		<div class="col s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img class="activator" src="https://www.nissan-cdn.net/content/dam/Nissan/br/vehicles/2016/Sentra/novo-sentra/04_PERFORMANCE/NISSAN_SENTRAMY17_0029_PERFORMANCE.png.ximg.l_12_m.smart.png">
				</div>
				<div class="card-content">
					<span class="card-title activator grey-text text-darken-4">Novo Sentra 2017<a class="btn-floating right circle red"><i class="material-icons right">add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4">Imformações<i class="material-icons right">close</i></span>
					<p class="textoJustificado">Motor 2.0L 16 válvulas flex, de 140 cv @ 5.100 rpm (etanol/gasolina) e 20 kgfm @ 4.800 rpm (etanol/gasolina).
						Câmbio manual de seis marchas ou câmbio automático XTRONIC CVT, dependendo da versão.

						Comprimento – 4.625 mm
						Largura – 1.761 mm
						Altura – 1.509 mm
						Distância entre-eixos – 2.700 mm
						Capacidade do porta-malas – 503 litros
					Capacidade do tanque de combustível – 50 litros</p>
				</div>
			</div>
		</div>
	</div>
	<br />
        <?php 
	include_once("Conexao.php");
       	$conexao = new Conexao();
       	$mobile = $conexao->getCon()->query("SELECT * FROM sports;");
       	$infor ="sports";
		foreach ($mobile as $key) { 
		echo "<div class='row visibleDesktop'>
		<div class='col s12'>
			<div class='card'>
				<div class='card-image waves-effect waves-block waves-light'>
					<img class='activator' src='../processas/exibirImg/exibirImgConteudo.php?id={$key['id']}&dados=$infor'width=100%'>
				</div>
				<div class='card-content'>
					<span class='card-title activator grey-text text-darken-4'>{$key['nomeCarro']}<a class='btn-floating right circle red'><i class='material-icons right'>add</i></a></span>
					<p>Click ao lado para saber mais</p>
				</div>
				<div class='card-reveal'>
					<span class='card-title grey-text text-darken-4'>Imformações<i class='material-icons right'>close</i></span>
					<p class='textoJustificado'>{$key['descricao']}</p>
				</div>
			</div>
		</div>
	</div>";}
	?>
	<!-- CONTEUDO DESKTOP -->
	<div class="container divBorda visibleMobile">
		<!-- NOTICIA1 DESKTOP -->
		
		<?php
		include_once("Conexao.php");
       	$conexao = new Conexao();
       	$sql = $conexao->getCon()->query("SELECT * FROM sports;");
       	$infor ="sports";
		foreach ($sql as $key) {
			echo "<hr /><!-- NOTICIA6 DESKTOP -->
				<div class='row visibleMobile'>
					<div class='col l12 m12'>
						<h4>{$key['nomeCarro']}</h4>
					</div>
					<div class='col l5 m5'>
						<img src='../processas/exibirImg/exibirImgConteudo.php?id={$key['id']}&dados=$infor'width=100% class='materialboxed responsive-img' />
					</div>
					<div class='col l7 m7'>
						<div>
							<p class='textoJustificado'>{$key['descricao']}</p>
						</div>
					</div>
				</div>";	
		}	
		?>
	</div>
	<br />
<?php
include_once("htmlBasico/rodapePags.php");
include_once("htmlBasico/linksPags.php");
?>	