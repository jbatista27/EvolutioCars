<?php session_start();
if($_SESSION['usuario'] == "admin"){
	include_once("htmlBasico/headPags.php");
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='conteudo/adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='conteudo/removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";

	echo "
		<!--Tabela-->
		<div class='row'>
		<div class='col s12 m12 l12'>
		<table class='responsive-table bordered'>
		<div class='divBorda visibleMobile'>
        <thead>
          <tr class'visibleMobile'>
              <th width='40px'>ID</th>
              <th width='50px'>Nome</th>
              <th width='50px'>Email</th>
              <th width='50px'>Senha</th>
              <th width='60px'>Excluir</th>
          </tr>
        </thead>
        </div>";
       include_once("Conexao.php");
       $conexao = new Conexao();
       $sql = $conexao->getCon()->query("SELECT * FROM usuario;");
       echo "<tbody>";
	      	foreach ($sql as $linha) {
		      	echo "<tr>";
		          echo"
		          <th>{$linha['id']}</th>
	              <th>{$linha['nome']}</th>
	              <th>{$linha['email']}</th>
	              <th>{$linha['senha']}</th>
	              <th><a href='../processas/remover/excluir.php?id={$linha['id']}&usuario=usuario' class='waves-effect blue btn'>Excluir</a></th>";
	            echo "</tr>
	            	";  
	       	}
		echo "</tbody>";
		echo "</table></div></div>";       

	include_once("htmlBasico/rodapePags.php");
	include_once("htmlBasico/linksPags.php");
}else if(isset($_SESSION['usuario'])){
		include_once("headPags.php");
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='../index.php' class='white-text'>Voltar Home</a></li> 	
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown3' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='editar.php' class='white-text'>Usuarios</a></li> 	
  		<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Conteudo</a></li> 
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown3'>Editar<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown4' class='dropdown-content blue'>
				<li><a href='editar.php' class='blue-text'>Usuarios</a></li> 	
  				<li><a href='conteudo/editarConteudo.php' class='blue-text-text'>Conteudo</a></li> 
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><img src='../img/logo.png' class='responsive-img'></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown4'>Editar<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
			</ul>
		</div>
	</nav>";

	echo "
		<!--Tabela-->
		<table class='responsive-table bordered'>
		<div class='divBorda'>
        <thead>
          <tr>
              <th>ID</th>
              <th>Nome dos Cadastrados</th>
              <th>Email</th>
              <th>Senha</th>
              <th>Excluir</th>
          </tr>
        </thead>
        </div>";
       include_once("Conexao.php");
       $conexao = new Conexao();
       $sql = $conexao->getCon()->query("SELECT * FROM cars;");
       echo "<tbody>";
	      	foreach ($sql as $linha) {
		      	echo "<tr>";
		          echo"
		          <th>{$linha['id']}</th>
	              <th>{$linha['user']}</th>
	              <th>{$linha['email']}</th>
	              <th>{$linha['senha']}</th>
	              <th><a href='../processas/remover/excluir.php?id={$linha['id']}' class='waves-effect blue btn'>Excluir</a></th>";
	            echo "</tr>
	            	";  
	       	}
		echo "</tbody>";
		echo "</table>
				<br /><br />";       

	include_once("htmlBasico/rodapePags.php");
	include_once("htmlBasico/linksPags.php");

	}else{
	header("Location: ../index.php");

}
?>	