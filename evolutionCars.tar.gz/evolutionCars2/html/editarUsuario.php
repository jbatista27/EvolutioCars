<?php session_start();
if($_SESSION['usuario'] == "admin"){
	include_once("htmlBasico/headPags.php");
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='../index.php' class='white-text'>Voltar Home</a></li> 	
  		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown3' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='editar.php' class='white-text'>Usuarios</a></li> 	
  		<li class='blue light-blue darken-2'><a href='conteudo/editarConteudo.php' class='white-text'>Conteudo</a></li> 
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown3'>Editar<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown4' class='dropdown-content blue'>
				<li><a href='editar.php' class='blue-text'>Usuarios</a></li> 	
  				<li><a href='conteudo/editarConteudo.php' class='blue-text-text'>Conteudo</a></li> 
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><img src='../img/logo.png' class='responsive-img'></li>
				<li><a href='../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='editar.php' class='white-text fontMenu'><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown4'>Editar</a><i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
			</ul>
		</div>
	</nav>";
       include_once("Conexao.php");
       $conexao = new Conexao();
		$id = $_GET['id'];
       $sql="SELECT * FROM usuario WHERE id=$id;";
       $seleciona = $conexao->getCon()->prepare($sql);
       $seleciona->execute();
       $dados= $seleciona->fetch(PDO::FETCH_OBJ);
    echo "<div class='container'><br /><br />
	<div class='row'>
		<fieldset>
		<legend class='fontMenu'>Login</legend>
		   <form class='col s12 l12 m12' method='post' enctype='multipart/form-data' action='../processas/atualizar/usuario/atualizarUsuario.php?id=$id'>
			    <div class='row'>
			      <div class='input-field col s12 l12 m12'>
			    		<input id='last_name' value=\"$dados->nome\" type='text' name='usuario' class='validate'>
			    		<label for='last_name'>Usuario</label>
			    	</div>
				</div>	
				<div class='row'>
			 		<div class='input-field col s12 l12 m12'>
						<input id='password' value=\"$dados->senha\" type='password' name='senha' class='validate'>
						<label for='password'>Senha</label>
					</div>
				</div>
				<div class='row'>
			 		<div class='input-field col s12 l12 m12'>
						<input id='email' value=\"$dados->email\" type='email' name='email' class='validate'>
						<label for='email'>Email:</label>
					</div>
				</div>
				<center>
					<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Editar</button>
				</center>    
			</form>
		</fieldset>
	</div>
	</div>   		"; 
	include_once("htmlBasico/rodapePags.php");
	include_once("htmlBasico/linksPags.php");
}else{
	header("Location: ../index.php");
}
?>	