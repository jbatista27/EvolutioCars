</body>
<!-- JQUERY -->
<script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
<!-- MATERIALIZE JS -->
<script src="js/materialize.min.js"></script>
<!-- JS LOCAL -->
<script type="text/javascript" src="js/app.js"></script>
<!-- PRELOADER -->
<script type="text/javascript" src="js/preloader.js"></script>
<script type="text/javascript" src="js/sweetalert2.js"></script>
</html>