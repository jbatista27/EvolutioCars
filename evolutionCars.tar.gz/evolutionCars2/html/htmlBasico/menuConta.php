<!-- MENU -->
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='index.html' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='html/login.php' class='white-text fontMenu'>{$_SESSION['usuario']}</a></li> 
			</ul>
			<!-- MENU MOBILE-->
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><img src='img/logo.png' class='responsive-img'></li>
				<li><a href='html/login.php' class='blue-text fontMenu'>{$_SESSION['usuario']}</a></li>  
			</ul>
		</div>
	</nav>
