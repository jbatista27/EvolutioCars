	<!-- RODAPE -->
	<footer class="page-footer light-blue darken-2">
		<div class="container">
			<div class="row">
				<div class="col l6 s12">
					<h5 class="white-text fontRodape">Frase Autoral!</h5>
					<p class="grey-text text-lighten-4" id="frase">Conheça um carro e aquilo que ele possa fazer, depois aventure-se nele!!</p>
				</div>
				<div class="col l4 offset-l2 s12">
					<h5 class="white-text fontRodape">Redes Sociais</h5>
					<ul>
						<li><a class="grey-text text-lighten-3" href="https://www.facebook.com/joaobatistarafaeul" target="_blank"><img class="circle" src="../img/facebook.png"></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="footer-copyright">
			<div class="container">
				© 2017 Desenvolvedor João Batista.
			</div>
		</div>  
	</footer>    