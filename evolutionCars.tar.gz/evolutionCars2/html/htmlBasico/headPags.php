<?php 
echo"<!DOCTYPE html>
<html lang='pt-br'>
<head>
	<title>EvolutionCars</title>
	<!-- ÍCONE DA PÁGINA -->
	<link rel='icon' href='../img/logo.png'>
	<meta charset='utf-8'/>
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>
	<!-- MATERIALIZE CSS -->
	<link rel='stylesheet' type='text/css' href='../css/materialize.min.css'>
	<!-- ESCALÁVEL PARA MOBILE -->
	<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
	<!-- CSS LOCAL -->
	<link rel='stylesheet' type='text/css' href='../css/style.css'>
	<!-- CSS PRELOADER -->
	<link rel='stylesheet' href='../css/stylePreloader.css' type='text/css' media='screen, print'/>
	<link rel='stylesheet' type='text/css' href='../css/sweetalert2.min.css' />
</head>
<body>";?>