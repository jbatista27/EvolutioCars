<?php session_start();
include_once("htmlBasico/headPags.php");
if (!isset($_SESSION['usuario'])) {
	header("Location: ../index.php");
} else {
	require_once("Conexao.php");
	$conexao = new Conexao();
	$id = $_GET['id'];
	$sql="SELECT * FROM usuario WHERE id=$id;";
    $seleciona = $conexao->getCon()->prepare($sql);
    $seleciona->execute();
    $dados= $seleciona->fetch(PDO::FETCH_OBJ);
	echo "<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content' blue>
		<li class='blue light-blue darken-2'><a href='../index.php' class='white-text'>Voltar Para Home</a></li>
		<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li>  	
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../index.php' class='brand-logo'><img src='../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><img width='60px' style='margin-top:10px;' src='../processas/exibirImg/exibir.php?id=$id' class='circle' /></li>
			</ul>
			
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content' blue>
				<li class='blue light-blue darken-2'><a href='../index.php' class='white-text'>Voltar Para Home</a></li>
				<li class='blue light-blue darken-2'><a href='../processas/sair.php' class='white-text'>Sair</a></li>  	
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><img class='responsive-img' src='../processas/exibirImg/exibir.php?id=$id'></li>
				<a class='dropdown-button fontMenu blue' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right blue'>arrow_drop_down</i></a></li>  
			</ul>
		</div>
	</nav>
	<div class='row'>
		<!-- imagem -->
			<br />
			<div class='col s12 m5 l5'>
			<fieldset>
				<form method='post' enctype='multipart/form-data' action='../processas/atualizar/imagem/atualizarImagem.php?id=$id&dados=usuario'>
					<img width='100%' height='300px' src='../processas/exibirImg/exibir.php?id=$id'>
				<div class='row'>
			 		<div class='input-field col s12 l12 m12 file-field'>
			 			<div class='btn blue'>
			 				<span><i class='material-icons'>attachment</i></span>
							<input id='imagem' type='file' name='imagem' class='validate'>
						</div>
						<div class='file-path-wrapper'>
							<input type='text' class='file-path validate' />
						</div>
					</div>
					</div>
					<center>
						<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Trocar</button>
					</center>
				</form> 
			</fieldset>			
			</div>
			<div class='col s12 m6 l6'>
		<!-- Dados -->
		<fieldset>
		   <form class='col s12 l12 m12' method='post' enctype='multipart/form-data' action='../processas/atualizar/usuario/atualizarUsuario.php?id=$id'>
			    <div class='row'>
			    <div class='col s12 l12 m12'>
			      <div class='input-field'>
			    		<input id='last_name' value=\"$dados->nome\" type='text' name='usuario' class='validate'>
			    		<label for='nome'>Usuario</label>
			    	</div>
				</div>
				</div>	
				<div class='row'>
			 		<div class='input-field col s12 l12 m12'>
						<input id='password' value=\"$dados->senha\" type='password' name='senha' class='validate'>
						<label for='password'>Senha</label>
					</div>
				</div>
				<div class='row'>
			 		<div class='input-field col s12 l12 m12'>
						<input id='email' value=\"$dados->email\" type='email' name='email' class='validate'>
						<label for='email'>Email:</label>
					</div>
				</div>
				<center>
					<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Trocar</button>
				</center>    
			</form>
		</fieldset>
			</div>
		</div>
";
}
include_once("htmlBasico/rodapePags.php");
include_once("htmlBasico/linksPags.php");
?>