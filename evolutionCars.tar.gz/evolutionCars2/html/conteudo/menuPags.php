<!-- MENU -->
	<nav class="light-blue darken-2">
		<div class="nav-wrapper container">
			<a href="../../index.php" class="brand-logo"><img src="../../img/logo.png" class="visibleMobile" width="83px;"></a>
			<a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
			<ul class="right hide-on-med-and-down negrito">
				<li><a href="../../index.php" class="white-text fontMenu" >Home</a></li>
				<li><a href="../sports.php" class="white-text fontMenu">Sports</a></li>
				<li><a href="../importados.php" class="white-text fontMenu">Importados</a></li>
				<li><a href="../classicos.php" class="white-text fontMenu">Clássicos</a></li>
				<li><a href="../cadastro.php" class="white-text fontMenu">Cadastro</a></li>
				<li><a href="../login.php" class="white-text fontMenu">Login</a></li>
			</ul>
			<!-- MENU MOBILE-->
			<ul class="side-nav negrito" id="mobile-demo">
				<li><img src="../../img/logo.png" class="circle responsive-img"></li>
				<li><a href="../../index.php" class="blue-text fontMenu">Home</a></li>
				<li><a href="../sports.php" class="blue-text fontMenu">Sports</a></li>
				<li><a href="../importados.php" class="blue-text fontMenu">Importados</a></li>
				<li><a href="../classicos.php" class="blue-text fontMenu">Clássicos</a></li>
				<li><a href="../cadastro.php" class="blue-text fontMenu">Cadastro</a></li>
				<li><a href="../login.php" class="blue-text fontMenu">Login</a></li> 
			</ul>
		</div>
	</nav>