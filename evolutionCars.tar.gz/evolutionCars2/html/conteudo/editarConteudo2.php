<?php session_start();
include_once("headPags.php");
if($_SESSION['usuario'] == "admin" && isset($_GET['home'])){
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../../index.php' class='brand-logo'><img src='../../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='../sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='../sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";
		include_once("../Conexao.php");
    	$conexao = new Conexao();

    	//PEGANDO AS ONFORMAÇÕES DA HOME
	$id = $_GET['id'];
		$infor = $_GET['home'];
        $sql="SELECT * FROM $infor WHERE id=$id;";
    	$seleciona = $conexao->getCon()->prepare($sql);
   		$seleciona->execute();
    	$dados= $seleciona->fetch(PDO::FETCH_OBJ);

    	//PEGANDO AS INFORMAÇÕES DE CURIOSIADE
    	$curi = $_GET['curiosidade'];
    	$sql2="SELECT * FROM curiosidade WHERE curiosidade='$curi';";
    	$seleciona2 = $conexao->getCon()->prepare($sql2);
   		$seleciona2->execute();
    	$dados2= $seleciona2->fetch(PDO::FETCH_OBJ);

    echo "<div class='container'>
	<div class='row'>
	<!-- imagem -->
			<br />
			<div class='col s12 m5 l5'>
			<fieldset>
				<legend class='fontMenu'>Editar Imagem</legend>
				<form method='post' enctype='multipart/form-data' action='../../processas/atualizar/imagem/atualizarImagem.php?id=$id&home=home&idCurio={$dados->id}'>
					<img width='100%' height='300px' src='../../processas/exibirImg/exibirImgConteudo.php?id=$id&dados=$infor' />
				<div class='row'>
			 		<div class='input-field col s12 l12 m12 file-field'>
			 			<div class='btn blue'>
			 				<span><i class='material-icons'>attachment</i></span>
							<input id='imagem' type='file' name='imagem' class='validate'>
						</div>
						<div class='file-path-wrapper'>
							<input type='text' class='file-path validate' />
						</div>
					</div>
				</div>
					<center>
						<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Trocar</button>
					</center>
				</form> 
			</fieldset>			
			</div>
			<div class='col s12 m7 l7'>
		<fieldset>
		<legend class='fontMenu'>Editar Conteudo</legend>
		   <form method='post' enctype='multipart/form-data' action='../../processas/atualizar/conteudo/atualizarConteudo.php?id=$id&home=home&curi=$curi'>
			      	<div class='input-field'>
			    		<input id='last_name' value=\"$dados->nomeCarro\" type='text' name='nomeCarro' class='validate'>
			    		<label for='last_name'>Usuario</label>
			    	</div>
			 		<div class='input-field'>
						<textarea style='max-width: 100%; height: 200px;' id='email' name='descricao' class='validate textarea textoJustificado'>{$dados->descricao}</textarea>
						<label for='email'>Descrição:</label>
					</div>
					<div class='input-field'>
			    		<input id='last_name' value=\"$dados2->curiosidade\" type='text' name='curiosidade' class='validate'>
			    		<label for='last_name'>Curiosidade</label>
			    	</div>
				<center>
					<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Editar</button>
				</center>    
			</form>
		</fieldset>
	</div>
		</div>
	</div>
	<div>"; 

	
}else if($_SESSION['usuario'] == "admin" && isset($_GET['dados'])){
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../../index.php' class='brand-logo'><img src='../../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='../sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='../sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";
		include_once("../Conexao.php");
    	$conexao = new Conexao();
        $id = $_GET['id'];
	$infor = $_GET['dados'];
        $sql="SELECT * FROM $infor WHERE id=$id;";
    	$seleciona = $conexao->getCon()->prepare($sql);
   		$seleciona->execute();
    	$dados= $seleciona->fetch(PDO::FETCH_OBJ);
    echo "<div class='container'>
	<div class='row'>
	<!-- imagem -->
			<br />
			<div class='col s12 m5 l5'>
			<fieldset>
				<legend class='fontMenu'>Editar Imagem</legend>
				<form method='post' enctype='multipart/form-data' action='../../processas/atualizar/imagem/atualizarImagem.php?id=$id&dados=$infor'>
					<img width='100%' height='300px' src='../../processas/exibirImg/exibirImgConteudo.php?id=$id&dados=$infor' />
				<div class='row'>
			 		<div class='input-field col s12 l12 m12 file-field'>
			 			<div class='btn blue'>
			 				<span><i class='material-icons'>attachment</i></span>
							<input id='imagem' type='file' name='imagem' class='validate'>
						</div>
						<div class='file-path-wrapper'>
							<input type='text' class='file-path validate' />
						</div>
					</div>
				</div>
					<center>
						<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Trocar</button>
					</center>
				</form> 
			</fieldset>			
			</div>
			<div class='col s12 m7 l7'>
		<fieldset>
		<legend class='fontMenu'>Editar Conteudo</legend>
		   <form method='post' enctype='multipart/form-data' action='../../processas/atualizar/conteudo/atualizarConteudo.php?id=$id&dados=$infor'>
			      <div class='input-field'>
			    		<input id='last_name' value=\"$dados->nomeCarro\" type='text' name='nomeCarro' class='validate'>
			    		<label for='last_name'>Usuario</label>
			    	</div>
			 		<div class='input-field'>
						<textarea style='max-width: 100%; height: 200px;' id='email' name='descricao' class='validate textarea textoJustificado'>{$dados->descricao}</textarea>
						<label for='email'>Descrição:</label>
					</div>
				<center>
					<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Editar</button>
				</center>    
			</form>
		</fieldset>
	</div>
		</div>
	</div>
	<div>"; 

}else{
	echo"<script>window.setTimeout(\"location.href='../../index.php'\",100);</script>";
}

include_once("rodapePags.php");
include_once("linksPags.php");
?>	