<?php session_start();
if($_SESSION['usuario'] == "admin"){
	include_once("headPags.php");
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../../index.php' class='brand-logo'><img src='../../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='../sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='../sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";
	echo "<div class='container'><br /><br />
	<div class='row'>
		<fieldset>
		<legend class='fontMenu'>Conteudo</legend>
		   <form class='col s12 l12 m12' method='post' enctype='multipart/form-data' action='../../processas/inserir/adicionarConteudo.php'>
			    <div class='row'>
			      <div class='input-field col s12 l6 m6'>
			    		<input id='last_name' type='text' name='nomeCarro' class='validate' required>
			    		<label for='last_name'>Nome Do Carro:</label>
			    	</div>
			    	<div class='col s12 l6 m6'>
			    		<select class='browser-default' name='local' onchange='optionCheck()' id='options' required>
			    			<option value='' disabled selected>Onde o Conteudo Vai Ficar:</option>
			    			<option value='1'>Home</option>
			    			<option value='2'>Sports</option>
			    			<option value='3'>Classicos</option>
			    			<option value='4'>Importados</option>

			    		</select>
			    	</div>
				</div>	
				<div class='row'>
			 		<div class='input-field col s12 l12 m12 file-field'>
			 			<div class='btn blue'>
			 			<span><i class='material-icons'>attachment</i></span>
						<input id='password' type='file' name='imagem' class='validate'>
						</div>
						<div class='file-path-wrapper'>
							<input type='text' class='file-path validate' />
						</div>
					</div>
				</div>
				<div class='row'>
			 		<div class='input-field col s12 l12 m12'>
						<textarea style='max-width: 100%; height: 300px;' id='email' name='descricao' class='validate textarea'>
						</textarea>
						<label for='email'>Descrição:</label>
					</div>
				</div>
				<div class='row' id='hiddenDiv' style='visibility:visible;'>
					<div class='input-field col s12 l12 m12'>
						<input id='last_name' type='text' name='curiosidade' class='validate'>
			    		<label for='last_name'>Curisidade</label>
					</div>
				</div>
				<center>
					<button class='btn waves-effect light-blue darken-2' type='submit' name='action' >Adicionar</button>
				</center>    
			</form>
		</fieldset>
	</div>
	</div>   		
	<br />"; 
	include_once("rodapePags.php");
	include_once("linksPags.php");
}else{
	header("Location: ../../index.php");
}

?>