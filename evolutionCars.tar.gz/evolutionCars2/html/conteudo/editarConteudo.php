<?php session_start();
if($_SESSION['usuario'] == "admin"){
	include_once("headPags.php");
	echo"<!-- MENU -->
	<ul id='dropdown1' class='dropdown-content blue'>
  		<li class='blue light-blue darken-2'><a href='../../processas/sair.php' class='white-text'>Sair</a></li> 
	</ul>
	<ul id='dropdown5' class='dropdown-content blue'>
		<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  		<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 <li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
	</ul>
	<nav class='light-blue darken-2'>
		<div class='nav-wrapper container'>
			<a href='../../index.php' class='brand-logo'><img src='../../img/logo.png' class='visibleMobile' width='83px;'></a>
			<a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
			<ul class='right hide-on-med-and-down negrito'>
				<li><a href='../../index.php' class='white-text fontMenu' >Home</a></li>
				<li><a href='../sports.php' class='white-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='white-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='white-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='white-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown5'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu' href='#!' data-activates='dropdown1'><span>{$_SESSION['usuario']}</span><i class='material-icons right'>arrow_drop_down</i></a></li>

			</ul>
			<!-- MENU MOBILE-->
			<ul id='dropdown2' class='dropdown-content'>
				<li><a href='../../index.php' class='blue-text'>Voltar Home</a></li> 	
  				<li><a href='../../processas/sair.php' class='blue-text'>Sair</a></li> 
			</ul>
			<ul id='dropdown6' class='dropdown-content blue'>
				<li class='blue light-blue darken-2'><a href='adicionar.php' class='white-text'>Adicionar</a></li> 	
  				<li class='blue light-blue darken-2'><a href='editarConteudo.php' class='white-text'>Editar</a></li>
  		 		<li class='blue light-blue darken-2'><a href='removerConteudo.php' class='white-text'>Remover</a></li>
			</ul>
			<ul class='side-nav negrito' id='mobile-demo'>
				<li><center><img src='../../img/logo.png' class='responsive-img' width=150px; heigth=30px;></center></li>
				<li><a href='../../index.php' class='blue-text fontMenu'>Home</a></li>
				<li><a href='../sports.php' class='blue-text fontMenu'>Sports</a></li>
				<li><a href='../importados.php' class='blue-text fontMenu'>Importados</a></li>
				<li><a href='../classicos.php' class='blue-text fontMenu'>Clássicos</a></li>
				<li><a href='../editar.php' class='blue-text fontMenu'>Usuarios</a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown6'>Conteudo<i class='material-icons right'>arrow_drop_down</i></a></li>
				<li><a class='dropdown-button fontMenu blue-text' href='#!' data-activates='dropdown2'><span>{$_SESSION['usuario']}</span><i class='material-icons right '>arrow_drop_down</i></a></li>
				
			</ul>
		</div>
	</nav>";
	include_once("../Conexao.php");
    $conexao = new Conexao();
    $home = $conexao->getCon()->query("SELECT home.id,home.nomeCarro,home.descricao,curiosidade.curiosidade,home.imagem
     FROM home INNER JOIN curiosidade ON home.curiosidade=curiosidade.id;");
    $idCuriosidade = $conexao->getCon()->query("SELECT*FROM curiosidade;");
    $sports = $conexao->getCon()->query("SELECT * FROM sports;");
    $importados = $conexao->getCon()->query("SELECT * FROM importados;");
    $classicos = $conexao->getCon()->query("SELECT * FROM classicos;"); 

    //HOME
	echo "
		<!--Tabela home-->
		<div class='row'>
		<div class='col s12 m12 l12'>
		<center><h3>Conteudo Da Pagina Home</h3><center>
		<table class='responsive-table bordered' >
		<div class='divBorda'>
        <thead>
          <tr>
              <th width='1%'>ID</th>
              <th width='10%'>Nome do Carro</th>
              <th width='40%'>Descrição</th>
              <th width='10%'>Curiosidade</th>
              <th  width='10%'>Imagem</th>
              <th width='8%'>Editar</th>
          </tr>
        </thead>
        </div>";
       echo "<tbody>";
	      	foreach ($home as $linha) {
		      	echo "<tr>";
		        echo"
		          <th>{$linha['id']}</th>
	              <th>{$linha['nomeCarro']}</th>
	              <th><p class='textoJustificado'>{$linha['descricao']}</p></th>
	              <th><p class='textoJustificado'>{$linha['curiosidade']}</p></th>
	              <th><img src='../../processas/exibirImg/exibirImgConteudo.php?id={$linha['id']}&dados=home' width='200px;'>
	              <th><a href='editarConteudo2.php?id={$linha['id']}&home=home&curiosidade={$linha['curiosidade']}&curiosidadeTable=curiosidade' class='waves-effect blue btn'>Editar</a></th>";

	            echo "</tr>";  
	       	}
		echo "</tbody>";
		echo "</table></div></div>";

    //SPORTS
	echo "
		<!--Tabela Sports-->
		<div class='row'>
		<div class='col s12 m12 l12'>
		<center><h3>Conteudo Da Pagina Sports</h3><center>
		<table class='responsive-table bordered' >
		<div class='divBorda'>
        <thead>
          <tr>
              <th width='1%'>ID</th>
              <th width='10%'>Nome do Carro</th>
              <th width='40%'>Descrição</th>
              <th  width='10%'>Imagem</th>
              <th width='8%'>Editar</th>
          </tr>
        </thead>
        </div>";
       echo "<tbody>";
	      	foreach ($sports as $linha) {
		      	echo "<tr>";
		        echo"
		          <th>{$linha['id']}</th>
	              <th>{$linha['nomeCarro']}</th>
	              <th><p class='textoJustificado'>{$linha['descricao']}</p></th>
	              <th><img src='../../processas/exibirImg/exibirImgConteudo.php?id={$linha['id']}&dados=sports' width='200px;'>
	              <th><a href='editarConteudo2.php?id={$linha['id']}&dados=sports' class='waves-effect blue btn'>Editar</a></th>";
	            echo "</tr>";  
	       	}
		echo "</tbody>";
		echo "</table></div></div>";

		//CLASSICOS
		echo "
		<!--Tabela Classicos-->
		<div class='row'>
		<div class='col s12 m12 l12'>
		<center><h3>Conteudo Da Pagina Classicos</h3><center>
		<table class='responsive-table bordered'>
		<div class='divBorda'>
        <thead>
          <tr>
              <th width='1%'>ID</th>
              <th width='10%'>Nome do Carro</th>
              <th width='40%'>Descrição</th>
              <th  width='10%'>Imagem</th>
              <th width='8%'>Editar</th>
          </tr>
        </thead>
        </div>";
       echo "<tbody>";
	      	foreach ($classicos as $linha) {
		      	echo "<tr>";
		        echo"
		          <th>{$linha['id']}</th>
	              <th>{$linha['nomeCarro']}</th>
	              <th><p class='textoJustificado'>{$linha['descricao']}<p></th>
	              <th><img src='../../processas/exibirImg/exibirImgConteudo.php?id={$linha['id']}&dados=classicos' width='200px;'>
	              <th><a href='editarConteudo2.php?id={$linha['id']}&dados=classicos' class='waves-effect blue btn'>Editar</a></th>";
	            echo "</tr>";  
	       	}
		echo "</tbody>";
		echo "</table></div></div>";

		//IMPORTADOS
		echo "
		<!--Tabela Importados-->
		<div class='row'>
		<div class='col s12 m12 l12'>
		<center><h3>Conteudo Da Pagina Importados</h3><center>
		<table class='responsive-table bordered'>
		<div class='divBorda'>
        <thead>
          <tr>
              <th width='1%'>ID</th>
              <th width='10%'>Nome do Carro</th>
              <th width='40%'>Descrição</th>
              <th  width='10%'>Imagem</th>
              <th width='8%'>Editar</th>
          </tr>
        </thead>
        </div>";
       echo "<tbody>";
	      	foreach ($importados as $linha) {
		      	echo "<tr>";
		        echo"
		          <th>{$linha['id']}</th>
	              <th>{$linha['nomeCarro']}</th>
	              <th><p class='textoJustificado'>{$linha['descricao']}</p></th>
	              <th><img src='../../processas/exibirImg/exibirImgConteudo.php?id={$linha['id']}&dados=importados' width='200px;'>
	              <th><a href='editarConteudo2.php?id={$linha['id']}&dados=importados' class='waves-effect blue btn'>Editar</a></th>";
	            echo "</tr>";  
	       	}
		echo "</tbody>";
		echo "</table></div></div>"; 
	
	include_once("rodapePags.php");
	include_once("linksPags.php");
}else{
	header("Location: ../../index.php");
}
?>	