<?php
$foto =$_FILES['imagem'];
$enviar = $foto['tmp_name'];

$imgbd = fopen($enviar,"rb");
require_once("../../../html/Conexao.php");
$conexao= new Conexao();
$id=$_GET['id'];
$dados = $_GET['dados'];
if (isset($_GET['home'])) {
	//ATUALIZAR A IMAGEM DA TABELA HOME
	try{
		$guardar="UPDATE home SET imagem=? WHERE id=$id;";
		$comando= $conexao->getCon()->prepare($guardar);
		$comando->bindParam(1,$imgbd,PDO::PARAM_LOB);
		$comando->execute();
		header("Location: ../../../html/conteudo/editarConteudo2.php?id=$id&home=home");
	}catch(Exception $e){
		echo $e->getMessage();
	}
}else{
	try{
		$guardar="UPDATE $dados SET imagem=? WHERE id=$id;";
		$comando= $conexao->getCon()->prepare($guardar);
		$comando->bindParam(1,$imgbd,PDO::PARAM_LOB);
		$comando->execute();
		header("Location: ../../../html/conteudo/editarConteudo2.php?id=$id&dados=$dados");
	}catch(Exception $e){
		echo $e->getMessage();
	}
}

?>	