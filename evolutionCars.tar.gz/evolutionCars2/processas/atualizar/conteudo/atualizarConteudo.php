<?php  
include_once('../../../html/Conexao.php');
$conexao = new Conexao();
if (isset($_GET['home'])) {
	//ATUALIZAR INFORMAÇÕES DA TABELA CURIOSIDADE
	$curi = $_GET['curi'];
	$campoCuriosidade = $_POST['curiosidade'];
	$atuaCurios = "UPDATE curiosidade SET curiosidade='$campoCuriosidade' WHERE curiosidade = '$curi';";
	$dados2 = $conexao->getCon()->prepare($atuaCurios);
	$dados2->execute();

	//ATUALIZAR AS INFORMAÇÕES DA HOME
	$id = $_GET['id'];
		$nomeCarro = $_POST['nomeCarro'];
		$descricao = $_POST['descricao'];
		$atualizar = "UPDATE home SET nomeCarro=:nomeCarro,descricao=:descricao WHERE id=$id;";
		$dados = $conexao->getCon()->prepare($atualizar);
		$dados->bindParam("nomeCarro",$nomeCarro);
		$dados->bindParam("descricao",$descricao);
		$dados->execute();
		header("Location: ../../../html/conteudo/editarConteudo2.php?id=$id&home=home&curiosidadeTable=curiosidade&curiosidade=$campoCuriosidade");
}else{
	try{
		$id = $_GET['id'];
		$infor = $_GET['dados'];
		$nomeCarro = $_POST['nomeCarro'];
		$descricao = $_POST['descricao'];
		$atualizar = "UPDATE $infor SET nomeCarro=:nomeCarro,descricao=:descricao WHERE id=$id;";
		$dados = $conexao->getCon()->prepare($atualizar);
		$dados->bindParam("nomeCarro",$nomeCarro);
		$dados->bindParam("descricao",$descricao);
		$dados->execute();
		header("Location: ../../../html/conteudo/editarConteudo2.php?id=$id&dados=$infor");
	}catch(Exception $e){
		echo $e->getMessage();
	}
}
?>