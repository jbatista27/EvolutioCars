<?php session_start();
if($_GET['id'] != null){
	include_once("../../../html/Conexao.php");
	$id = $_GET['id'];
	$usuario = $_POST['usuario'];
	$senha = $_POST['senha'];
	$email = $_POST['email'];
	$conexao = new Conexao();
	$atualizar = "UPDATE usuario SET nome=:usuario,senha=:senha,email=:email WHERE id=$id;";
	$dados = $conexao->getCon()->prepare($atualizar);
	$dados->bindParam("usuario",$usuario);
	$dados->bindParam("senha",$senha);
	$dados->bindParam("email",$email);
	$dados->execute();
	
	$_SESSION["usuario"] = $usuario;
	header("Location: ../../../index.php");
}else{
	header("Location: ../../../html/editar.php");
}
?>	