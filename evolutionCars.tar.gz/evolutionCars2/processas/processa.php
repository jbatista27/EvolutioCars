<?php session_start();
require_once("../html/Conexao.php");
$usuario = $_POST['usuario'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$cSenha = $_POST['confirSenha'];

$conexao = new Conexao();
$sql= $conexao->getCon()->prepare("SELECT * FROM usuario WHERE nome = ?;");
$sql->bindParam(1, $usuario);
$sql->execute();

$sqlemail = $conexao->getCon()->prepare("SELECT * FROM usuario WHERE email = ?;");
$sqlemail->bindParam(1, $email);
$sqlemail->execute();

	if ($sql->rowCount() > 0) {

			echo "<script>alert('Usuario ja existe');</script>";
			session_destroy();
			echo"<script>window.setTimeout(\"location.href='../html/cadastro.php'\",100);</script>";
                        session_destroy(); 
		} else if($sqlemail->rowCount() > 0){

					echo "<script>alert('Email já está cadastrado');</script>";
                                        session_destroy();
                                        echo"<script>window.setTimeout(\"location.href='../html/cadastro.php'\",100);</script>";
				}else{

					$sqli = $conexao->getCon()->prepare("INSERT INTO usuario SET nome=?, email=?, senha=?;");

					$sqli->bindParam(1, $usuario);
					$sqli->bindParam(2, $email);
					$sqli->bindParam(3, $senha);
					$sqli->execute();

					$sqlusu = $conexao->getCon()->prepare("SELECT * FROM usuario WHERE nome = ?;");
					$sqlusu->bindParam(1,$usuario);
					$sqlusu->execute();
					$oi = $sqlusu->fetch(PDO::FETCH_OBJ);
					$_SESSION["id"] = $oi->id;
					$_SESSION["usuario"] =$usuario;
					$_SESSION["senha"] = $senha;
					$_SESSION["email"] = $email;
                                       	echo"<script>window.setTimeout(\"location.href='../index.php'\",100);</script>";
					echo "<script>alert('Usuario cadastrado');</script>";

				
				}
			
/*$id = $conexao->getCon()->lastInsertId();
$md5 = md5($id);	
$assunto = "Confirme seu Cadastro";
$link = "batista.ntectreinamentos.com.br/html/confirmar.php?h=".$md5;
$mensagen = "Crick aqui para confirmar o seu cadastro".$link;
$header = "From: $usu";

mail($ema, $assunto, $mensagen, $header);
*/
//$arrays = "arrays";
/*if ($email != null) {
	$email = strtolower("$email");
	//criar pasta para os usuarios
	mkdir("../arquivoUsuarios/$email", 0777);
	$arquivoUsuario = fopen("../arquivoUsuarios/$email/infor.txt", "w");
	fwrite($arquivoUsuario, "Usuario: $usuario | Email: $email | Senha: $senha");
	fclose($arquivoUsuario);
	mkdir("../arquivoUsuarios/$arrays", 0777);
	$arrayUsuario = array("$usuario , $senha" );
	$arquivoArray = fopen("../arquivoUsuarios/$arrays/array.txt", "w");
	$arrUsuString = implode(",",$arrayUsuario);
	fwrite($arquivoArray, "$arrUsuString");
	
} else {
	echo "preencha o email";
	header("Location: cadastro.php");
}*/


?>