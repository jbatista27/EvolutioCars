<?php 
	$id= $_GET['id'];
	require_once("../../html/Conexao.php");
	$conexao = new Conexao();
	$sql=$conexao->getCon()->prepare("SELECT imagem FROM usuario WHERE id=?;");
	$sql->bindParam(1,$id);
	$sql->execute();
	$sql->bindColumn(1,$img,PDO::PARAM_LOB);
	$arquivo= $sql->fetch(PDO::FETCH_BOUND);
	header("Content-type: image");
	echo $img;
?>