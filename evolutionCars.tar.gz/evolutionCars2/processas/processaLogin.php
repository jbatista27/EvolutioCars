<?php session_start();
	require_once("../html/htmlBasico/headPags.php");
	require_once("../html/Conexao.php");
	$conexao = new Conexao();
	$usuario =$_POST["usuario"];
	$senha = $_POST["senha"];


	if($usuario == "admin" && $senha == "qwe123"){
		$sqlusu = $conexao->getCon()->prepare("SELECT * FROM superUsuario WHERE nome = ?;");
		$sqlusu->bindParam(1, $usuario);
		$sqlusu->execute();
		$sqlsenha = $conexao->getCon()->prepare("SELECT * FROM superUsuario WHERE senha = ?;");
		$sqlsenha->bindParam(1,$senha);
		$sqlsenha->execute();
		
		if ($sqlusu->rowCount() > 0 && $sqlsenha->rowCount() > 0){ 
                                $_SESSION['usuario'] = $usuario;
				$_SESSION['senha'] = $senha;
				echo"<script>window.setTimeout(\"location.href='../index.php'\",100);</script>";
			} else if($sqlusu->rowCount() == 0){
                                        header("Refresh:1, ../html/login.php");
					echo "<script>alert('Usuario Não cadastrado');</script>";
					session_destroy();
				}else if($sqlsenha->rowCount() ==0){
					echo "<script>alert('Senha do Adminincorreto');</script>";
					header("Refresh:1, ../html/login.php");
					session_destroy();
				}
	}else{

		$sqlusu = $conexao->getCon()->prepare("SELECT * FROM usuario WHERE nome = ?;");
		$sqlusu->bindParam(1,$usuario);
		$sqlusu->execute();
		$oi = $sqlusu->fetch(PDO::FETCH_OBJ);

		$sqlsenha = $conexao->getCon()->prepare("SELECT * FROM usuario WHERE senha = ?;");
		$sqlsenha->bindParam(1,$senha);
		$sqlsenha->execute();



		if ($sqlusu->rowCount() > 0 && $sqlsenha->rowCount() > 0) {
				$_SESSION['usuario'] = $usuario;
				$_SESSION['senha'] = $senha;
				$_SESSION["id"] = $oi->id;
				echo"<script>window.setTimeout(\"location.href='../index.php'\",100);</script>";
			} else if($sqlusu->rowCount() == 0){
                                        echo"<script>window.setTimeout(\"location.href='../html/login.php'\",100);</script>";
					echo "<script>alert('Usuario Não Cadastrado');</script>";
					session_destroy();
				}else if($sqlsenha->rowCount() ==0){
					echo "<script>alert('Senha incorreta');</script>";
                                        echo"<script>window.setTimeout(\"location.href='../html/login.php'\",100);</script>";
					session_destroy();
				}
	}
?>