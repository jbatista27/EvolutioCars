<?php 
require_once("../../html/Conexao.php");
$conexao= new Conexao();
$nomeCarro =$_POST['nomeCarro'];
$descricao = $_POST['descricao'];

$foto =$_FILES['imagem'];
$enviar = $foto['tmp_name'];
$imgbd = fopen($enviar,"rb");

	if ($_POST['local'] == 1) { //HOME
		try{

			$curiosidade = $_POST['curiosidade'];
			$conteudo = $conexao->getCon()->prepare("INSERT INTO curiosidade(curiosidade) VALUES(?);");
			$conteudo->bindParam(1,$curiosidade);
			$conteudo->execute();
			$con = $conexao->getCon()->lastInsertId();

			$conteudo2 =$conexao->getCon()->prepare("INSERT INTO home(nomeCarro,descricao,curiosidade,imagem) VALUES(?,?,?,?);");
			$conteudo2->bindParam(1,$nomeCarro);
			$conteudo2->bindParam(2,$descricao);
			$conteudo2->bindParam(3,$con);
			$conteudo2->bindParam(4,$imgbd,PDO::PARAM_LOB);
			$conteudo2->execute();

		}catch(PDOExecption $e) { 
			 print "Error!: " . $e->getMessage() . "</br>"; 
		}	
	}else if($_POST['local'] == 2){ //SPORTS
			$conteudo =$conexao->getCon()->prepare("INSERT INTO sports(nomeCarro,descricao,imagem) VALUES(?,?,?);");
			$conteudo->bindParam(1,$nomeCarro);
			$conteudo->bindParam(2,$descricao);
			$conteudo->bindParam(3,$imgbd,PDO::PARAM_LOB);
			$conteudo->execute();
	}else if ($_POST['local'] == 3) { // CLASSICOS
			$conteudo =$conexao->getCon()->prepare("INSERT INTO classicos(nomeCarro,descricao,imagem) VALUES(?,?,?);");
			$conteudo->bindParam(1,$nomeCarro);
			$conteudo->bindParam(2,$descricao);
			$conteudo->bindParam(3,$imgbd,PDO::PARAM_LOB);
			$conteudo->execute();
	}else if ($_POST['local'] == 4) { //IMPORTADOS
			$conteudo =$conexao->getCon()->prepare("INSERT INTO importados(nomeCarro,descricao,imagem) VALUES(?,?,?);");
			$conteudo->bindParam(1,$nomeCarro);
			$conteudo->bindParam(2,$descricao);
			$conteudo->bindParam(3,$imgbd,PDO::PARAM_LOB);
			$conteudo->execute();
	}
header("Location: ../../html/conteudo/adicionar.php");
?>