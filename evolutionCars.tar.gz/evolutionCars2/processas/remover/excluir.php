<?php
	include_once("../../html/Conexao.php");
	$conexao = new Conexao();

	if (isset($_GET['usuario'])) {
		$id = $_GET['id'];
		$sql = $conexao->getCon()->prepare("DELETE FROM usuario WHERE id=? ;");
		$sql->bindParam(1,$id);
		$sql->execute();
		header("Refresh:0.05, ../../html/editar.php");
		echo "<script>alert('Usuario Excluido')</script>";
	}else if (isset($_GET['sports'])) {
		$id = $_GET['id'];
		$sql = $conexao->getCon()->prepare("DELETE FROM sports WHERE id=? ;");
		$sql->bindParam(1,$id);
		$sql->execute();
		header("Refresh:0.05, ../../html/conteudo/removerConteudo.php");
		echo "<script>alert('Conteudo apagado')</script>";
	}else if (isset($_GET['classicos'])) {
		$id = $_GET['id'];
		$sql = $conexao->getCon()->prepare("DELETE FROM classicos WHERE id=? ;");
		$sql->bindParam(1,$id);
		$sql->execute();
		header("Refresh:0.05, ../../html/conteudo/removerConteudo.php");
		echo "<script>alert('Conteudo apagado')</script>";
	}else if (isset($_GET['importados'])) {
		$id = $_GET['id'];
		$sql = $conexao->getCon()->prepare("DELETE FROM importados WHERE id=? ;");
		$sql->bindParam(1,$id);
		$sql->execute();
		header("Refresh:0.05, ../../html/conteudo/removerConteudo.php");
		echo "<script>alert('Conteudo apagado')</script>";
	}else if(isset($_GET['home'])){
		$id = $_GET['id'];
		$curiosidade = $_GET['infor'];
		
		$sql = $conexao->getCon()->prepare("DELETE FROM home WHERE id=?;");
		$sql->bindParam(1,$id);
		$sql->execute();
		$sql2 = $conexao->getCon()->prepare("DELETE FROM curiosidade WHERE curiosidade=?;");
		$sql2->bindParam(1,$curiosidade);
		$sql2->execute();
		header("Refresh:0.05, ../../html/conteudo/removerConteudo.php");
		echo "<script>alert('Conteudo apagado')</script>";
	}
	
?>